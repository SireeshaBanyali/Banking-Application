package com.userserviceapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class AuthenticationServiceApplicationForBanking {

	public static void main(String[] args) {
		SpringApplication.run(AuthenticationServiceApplicationForBanking.class, args);
	}
	@Bean
	public RestTemplate ClientRestTemplate(){

		return new RestTemplate();
	}

}
