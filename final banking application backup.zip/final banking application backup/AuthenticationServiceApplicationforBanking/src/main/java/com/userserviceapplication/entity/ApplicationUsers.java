package com.userserviceapplication.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "fl_app_users")
public class ApplicationUsers {
	@Id
	@GeneratedValue
	private Integer id;
	private String employeeName;
	private String employeeEmailId;
	private String empRole;
	private String contactNumber;
	private String userName;
	private String password;
	private String lastLogInTime;
	public ApplicationUsers() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ApplicationUsers(Integer id, String employeeName, String employeeEmailId, String empRole,
			String contactNumber, String userName, String password, String lastLogInTime) {
		super();
		this.id = id;
		this.employeeName = employeeName;
		this.employeeEmailId = employeeEmailId;
		this.empRole = empRole;
		this.contactNumber = contactNumber;
		this.userName = userName;
		this.password = password;
		this.lastLogInTime = lastLogInTime;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getEmployeeEmailId() {
		return employeeEmailId;
	}
	public void setEmployeeEmailId(String employeeEmailId) {
		this.employeeEmailId = employeeEmailId;
	}
	public String getEmpRole() {
		return empRole;
	}
	public void setEmpRole(String empRole) {
		this.empRole = empRole;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getLastLogInTime() {
		return lastLogInTime;
	}
	public void setLastLogInTime(String lastLogInTime) {
		this.lastLogInTime = lastLogInTime;
	}
	@Override
	public String toString() {
		return "ApplicationUsers [id=" + id + ", employeeName=" + employeeName + ", employeeEmailId=" + employeeEmailId
				+ ", empRole=" + empRole + ", contactNumber=" + contactNumber + ", userName=" + userName + ", password="
				+ password + ", lastLogInTime=" + lastLogInTime + "]";
	}
	
	
	

}
