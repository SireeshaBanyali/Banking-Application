
package com.userserviceapplication.service.impl;

import java.util.List;
import java.util.Set;

import com.userserviceapplication.exceptions.ApiException;
import com.userserviceapplication.repository.RoleRepository;
import com.userserviceapplication.repository.UserRepository;
import com.userserviceapplication.services.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.userserviceapplication.entity.User;
import com.userserviceapplication.entity.UserRole;
import com.userserviceapplication.util.UtilsMethods;



@Service
public class UserServiceImpl implements UserService {
	private static Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

	@Autowired
	private UserRepository userRepository;
	@Autowired
	private RoleRepository roleRepository;

	
	UtilsMethods um = new UtilsMethods();
	
	@Override
	public User saveUser(User user, Set<UserRole> userRole) throws RuntimeException {
		
		logger.info("========= User Object In Service Class================" + user);
		//logger.info("========= Role Object In Controller================" + ur);
		logger.info("========= User Roles In Service Class================" + userRole);
		
		User userFromDb = this.userRepository.findByUserName(user.getUsername());
		if(userFromDb != null) {
			logger.error("User already Exists.");
			
//			throw new CustomException(0,"User","User info is already present in the DB");
			throw new RuntimeException("User info is already present in the DB");
		}else {
			for(UserRole ur : userRole) {
				roleRepository.save(ur.getRole());
			}
			user.getUserRoles().addAll(userRole);
			userFromDb =  this.userRepository.save(user);
		}
		return userFromDb;
	}

	@Override
	public User getUserByUserName(String userName) {
		User user = this.userRepository.findByUserName(userName);
		return user;
	}

	@Override
	public List<User> getAllUsersInfo() {
		List<User> list = this.userRepository.findAll();
		if(list.size() == 0 || list == null)
			throw new ApiException("No users found in Database.😒😒😒");
		
		return list;
	}
	
	
	
	
	
	

}

