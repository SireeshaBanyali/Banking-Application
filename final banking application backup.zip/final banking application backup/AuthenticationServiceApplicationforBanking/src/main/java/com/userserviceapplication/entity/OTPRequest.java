package com.userserviceapplication.entity;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class OTPRequest {
    private int otp;
    private String email;

}
