package com.userserviceapplication.client;

import lombok.Data;

import java.util.Date;

@Data
public class User {

    private String first_name;
    private String last_Name;
    private long phone_number;
    private Date date_Of_Birth;
    private String pan_number;

    private Address permanentAddress;
    private Address CurrentAddress;
    private String gender;
    private String emailId;
    private String password;
    private String confirm_password;

}
