package com.userserviceapplication.repository;


import com.userserviceapplication.entity.UserLoginDetails;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AuthenticationRepository extends JpaRepository<UserLoginDetails,Integer> {

}
