package com.userserviceapplication.util;

import lombok.Data;

@Data
public class ErrorClass {

    private String message;
    private String code;

}
