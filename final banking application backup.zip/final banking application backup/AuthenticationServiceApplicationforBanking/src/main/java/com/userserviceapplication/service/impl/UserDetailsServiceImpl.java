
package com.userserviceapplication.service.impl;

import com.userserviceapplication.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.userserviceapplication.entity.User;


@Service
public class UserDetailsServiceImpl implements UserDetailsService {
	private static Logger logger = LoggerFactory.getLogger(UserDetailsServiceImpl.class);
	
	@Autowired
	private UserRepository userRepository;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		User user = this.userRepository.findByUserName(username);
		if(user == null) {
			logger.error("User not found in DB");
			throw new UsernameNotFoundException("No User found with this Username");
		}
		return user;
	}

}

