package com.userserviceapplication.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class OTPData {
    @Id
    @GeneratedValue
    private int id;
    private int otp;
    private String expiryTime;
    private String guid;
    private String emailId;

    public OTPData(int otp, String expiryTime, String emailId) {
        this.otp = otp;
        this.expiryTime = expiryTime;
        this.emailId = emailId;
    }
}
