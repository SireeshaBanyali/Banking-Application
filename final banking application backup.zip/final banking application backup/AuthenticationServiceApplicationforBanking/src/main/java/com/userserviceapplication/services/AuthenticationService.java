package com.userserviceapplication.services;


import com.userserviceapplication.entity.UserLoginDetails;
import com.userserviceapplication.util.AuthResponse;

public interface AuthenticationService {

    public UserLoginDetails userlogin(UserLoginDetails userdetails);
    public AuthResponse validateUser(UserLoginDetails userLoginObj);
}
