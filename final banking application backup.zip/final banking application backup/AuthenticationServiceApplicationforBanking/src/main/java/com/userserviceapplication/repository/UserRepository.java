
package com.userserviceapplication.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.userserviceapplication.entity.User;




public interface UserRepository extends JpaRepository<User, Long> {
	User findByUserName(String userName);
	User findByEmail(String email);
}
