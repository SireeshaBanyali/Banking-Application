package com.userserviceapplication.repository;


import com.userserviceapplication.entity.OTPData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface OTPDataRepository extends JpaRepository<OTPData,Integer> {
    @Query(value="select * from otpdata where email_id=? order by expiry_time desc limit 1",nativeQuery = true)
    public OTPData getLatestOtp(String emailId);
}
