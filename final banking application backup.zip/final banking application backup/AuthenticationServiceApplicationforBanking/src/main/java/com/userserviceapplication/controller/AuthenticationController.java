package com.userserviceapplication.controller;

import java.security.Principal;

import com.userserviceapplication.client.UserClient;
import com.userserviceapplication.entity.*;
import com.userserviceapplication.exceptions.ApiException;
import com.userserviceapplication.service.impl.AuthenticationServiceImpl;
import com.userserviceapplication.service.impl.OTPServiceImpl;
import com.userserviceapplication.util.AuthResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

import com.userserviceapplication.config.JwtUtils;
import com.userserviceapplication.service.impl.UserDetailsServiceImpl;




@RestController
@CrossOrigin("*")
public class AuthenticationController {
	@Autowired
	private AuthenticationManager authenticationManager;
	
	@Autowired
	private UserDetailsServiceImpl userDetailsServiceImpl;
	
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	@Autowired
	private JwtUtils jwtUtils;
	@Autowired
	private AuthenticationServiceImpl authenticationServiceImpl;
	@Autowired
	private OTPServiceImpl otpServiceImpl;

	@Autowired
	private UserClient userClient;

	private static Logger logger = LoggerFactory.getLogger(AuthenticationController.class);

	
	//Generate token
	@PostMapping("/generate-token")
	public ResponseEntity<?> generateToken(@RequestBody JwtRequest jwtRequest) throws Exception{
		logger.info("=========password in AuthController genrateToken ================"+jwtRequest.getPassword());
		
		logger.info("=========Username in AuthController genrateToken ================"+jwtRequest.getUserName());
		String password = bCryptPasswordEncoder.encode(jwtRequest.getPassword());
		logger.info("=========password in AuthController After Encryption genrateToken================"+password);
		
		
		try {
			authenticate(jwtRequest.getUserName(), jwtRequest.getPassword());
		}catch (Exception e) {
			e.printStackTrace();
			throw new ApiException("No Such User found in the  Database kindly check the login credentials.");
		}
		
		//Authenticate
		UserDetails userDetails = this.userDetailsServiceImpl.loadUserByUsername(jwtRequest.getUserName());
		String token = this.jwtUtils.generateToken(userDetails);
		return ResponseEntity.ok(new JwtResponse(token));
	}
	
	
	private void authenticate(String username,String password) throws Exception {
		
		try {
			authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
		}catch (DisabledException e) {
			throw new Exception("User is disabled "+e.getMessage());
		}catch (BadCredentialsException e) {
			throw new Exception("Invalid Credentials )-: "+e.getMessage());
		}
	}
	
	@GetMapping("/current-user")
	public User getCurrentUser(Principal principal) {
		return ((User) this.userDetailsServiceImpl.loadUserByUsername(principal.getName()));
	}

	@PostMapping("/validate")
	public ResponseEntity<AuthResponse> validateUser(@RequestBody UserLoginDetails userLoginDetails){
		AuthResponse user = this.authenticationServiceImpl.validateUser(userLoginDetails);
		if(user.getStatus().equalsIgnoreCase("success")){
			return ResponseEntity.ok(user);
		}
		return new ResponseEntity<>(user,HttpStatus.BAD_REQUEST);
	}

	@PostMapping("/otpValidation")
	public ResponseEntity<String> otpvalidation(@RequestBody OTPRequest or){


			boolean status = otpServiceImpl.validateOtp(or.getOtp(), or.getEmail());
			System.out.println("OTP Validate status : " + status);
			if (status) {

				logger.info("=========password in AuthController genrateToken ================" + or.getEmail());

				logger.info("=========Username in AuthController genrateToken ================" + or.getOtp());
				String password = bCryptPasswordEncoder.encode(or.getEmail());
				logger.info("=========password in AuthController After Encryption genrateToken================" + password);


				String token = this.jwtUtils.generateToken(or.getEmail());

				return ResponseEntity.ok(String.valueOf(new JwtResponse(token)));
			}

		else{
			return new ResponseEntity<>("Invalid OTP",HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping("/validate-token/{jwtToken}")
	public ResponseEntity<String> validateToken(@PathVariable String jwtToken){
		String response = this.otpServiceImpl.validateJWTToken(jwtToken);
		return ResponseEntity.ok(response);
	}


}
