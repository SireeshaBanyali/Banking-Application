package com.userserviceapplication.client;


import com.userserviceapplication.service.impl.AuthenticationServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class UserClient {

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private AuthenticationServiceImpl serviceImpl;

    public ResponseEntity<User> getUsers(){

        String endpoint="http://localhost:9072/user/getAllUsers";
       ResponseEntity<User> user=restTemplate.getForEntity(endpoint,User.class);
        System.out.println(user);
       return new  ResponseEntity<User>(user.getBody(), HttpStatus.OK);
    }



}
