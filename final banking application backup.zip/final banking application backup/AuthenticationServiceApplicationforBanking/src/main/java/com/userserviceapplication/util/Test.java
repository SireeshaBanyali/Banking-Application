package com.userserviceapplication.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;

public class Test {
	
	public static void main(String[] args) throws ParseException {
		UtilsMethods um = new UtilsMethods();
		SimpleDateFormat sdformat = new SimpleDateFormat("yyyy-MM-dd");
	       LocalDate today = LocalDate.now();
	       String currentDate = um.getCurrentDateInYMD();
	       System.out.println(currentDate);
	       //currentDate = currentDate.substring(0,10);
	       Date d1 = sdformat.parse(currentDate);
	      Date d2 = sdformat.parse("2022-08-12");
	      System.out.println("The date 1 is: " + sdformat.format(d1));
	      System.out.println("The date 2 is: " + sdformat.format(d2));
	      if(d1.compareTo(d2) > 0) {
	         System.out.println("Date 1 occurs after Date 2");
	      } else if(d1.compareTo(d2) < 0) {
	         System.out.println("Date 1 occurs before Date 2");
	      } else if(d1.compareTo(d2) == 0) {
	         System.out.println("Both dates are equal");
	      }
	}
}
