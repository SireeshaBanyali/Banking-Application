package com.userserviceapplication.services;

public interface OTPService {
}
