package com.userserviceapplication.util;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class AuthResponse {
    private String status;
    private AuthenticationResponse data;

    private ErrorClass errors;

    public AuthResponse(String success, String userValidated) {
    }
}
