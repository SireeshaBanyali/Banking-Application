package com.userserviceapplication.services;

import java.util.List;

import com.userserviceapplication.entity.ApplicationUsers;
import com.userserviceapplication.util.ApiResponse;

public interface AppUserServices {
	
	ApiResponse saveUserInfo(ApplicationUsers appUsers);
	ApiResponse  validateUser(ApplicationUsers applicationUsers);
	List<ApplicationUsers> fetchAllUsersInfo();
	List<ApplicationUsers> fetchAllAgentsInfo();
	//List<ApplicationUsers> fetchAllClientsInfo();
	
}
