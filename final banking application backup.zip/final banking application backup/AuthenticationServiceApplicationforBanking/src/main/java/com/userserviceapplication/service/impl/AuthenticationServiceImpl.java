package com.userserviceapplication.service.impl;


import com.userserviceapplication.client.User;
import com.userserviceapplication.entity.OTPData;
import com.userserviceapplication.entity.UserLoginDetails;
import com.userserviceapplication.repository.AuthenticationRepository;
import com.userserviceapplication.services.AuthenticationService;
import com.userserviceapplication.util.AuthResponse;
import com.userserviceapplication.util.AuthenticationResponse;
import com.userserviceapplication.util.ErrorClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

@Service
public class AuthenticationServiceImpl implements AuthenticationService {

    @Autowired
    private RestTemplate restTemplate;
    @Autowired
    private AuthenticationRepository repository;

    @Autowired
    private OTPServiceImpl otpService;

    public UserLoginDetails userlogin(UserLoginDetails userdetails){
        return repository.save(userdetails);
    }

    @Override
    public AuthResponse validateUser(UserLoginDetails userLoginObj) {
        System.out.println(userLoginObj);

        String endpoint="http://localhost:9072/user/fetch/user";
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        Map<String, String> requestBody = new HashMap<>();
        requestBody.put("emailId", userLoginObj.getEmail());
        requestBody.put("password", userLoginObj.getPassword());
        HttpEntity<Map<String, String>> requestEntity = new HttpEntity<>(requestBody, headers);
        ResponseEntity<User> response = restTemplate.postForEntity(endpoint, requestEntity, User.class);
        User responseBody = response.getBody();
        System.out.println(responseBody);
        AuthResponse resp = new AuthResponse();
        if(responseBody == null){
            System.out.println("Wrong credentails");
            ErrorClass error=new ErrorClass();
            error.setCode("1001");
            error.setMessage("Invalid username and password");
            resp.setErrors(error);
            resp.setStatus("Failed");
            //throw new RuntimeException("Please check the login credntials ");
            return resp;
        }
        repository.save(userLoginObj);
        Random random = new Random();
        int generatedOTP = random.nextInt(10000) + 1000;
        System.out.println("Generated OTP For User "+responseBody.getLast_Name() +": "+ generatedOTP);
        UUID uuid = UUID.randomUUID();
        String gUid = uuid.toString();
        System.out.println("Generated GUID For User "+responseBody.getLast_Name() +": " + gUid);


        // get the current date and time
        LocalDateTime currentDateTime = LocalDateTime.now();

        // add 5 minutes to the current date and time
        LocalDateTime newDateTime = currentDateTime.plusMinutes(10);

        // format the new date and time as a string
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String expiryTime = newDateTime.format(formatter);

        System.out.println("Current date and time: " + currentDateTime);
        System.out.println("Expiry Time for OTP: " + expiryTime);
        AuthenticationResponse authenticationResponse = new AuthenticationResponse();
        authenticationResponse.setGuid(gUid);
        authenticationResponse.setOtp(generatedOTP);
        authenticationResponse.setValidTill(expiryTime);


        resp.setStatus("Success");
        resp.setData(authenticationResponse);
        ErrorClass error =new ErrorClass();
        resp.setErrors(error);

        OTPData otpData = new OTPData();
        otpData.setOtp(generatedOTP);
        otpData.setGuid(gUid);
        otpData.setExpiryTime(expiryTime);
        otpData.setEmailId(userLoginObj.getEmail());
        otpService.save(otpData);

        return resp;
    }
}
