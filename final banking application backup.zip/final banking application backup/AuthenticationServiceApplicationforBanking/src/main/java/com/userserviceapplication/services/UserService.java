
package com.userserviceapplication.services;

import java.util.List;
import java.util.Set;

import com.userserviceapplication.entity.User;
import com.userserviceapplication.entity.UserRole;


public interface UserService {
	User saveUser(User user,Set<UserRole> userRole);
	User getUserByUserName(String userName);
	List<User> getAllUsersInfo();
}

