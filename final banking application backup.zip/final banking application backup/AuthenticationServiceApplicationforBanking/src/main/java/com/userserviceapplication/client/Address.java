package com.userserviceapplication.client;

import lombok.Data;

@Data
public class Address {
    private String door_number;
    private String street;
    private String area;
    private String city;
    private String state;
    private String state_Code;
    private long pin_code;
}
