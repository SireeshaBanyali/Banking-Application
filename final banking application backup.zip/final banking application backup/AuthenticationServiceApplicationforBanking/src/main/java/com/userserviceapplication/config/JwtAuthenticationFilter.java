 
package com.userserviceapplication.config;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.userserviceapplication.exceptions.ApiException;
import com.userserviceapplication.exceptions.UserDefinedException;
import com.userserviceapplication.service.impl.UserDetailsServiceImpl;
import io.jsonwebtoken.SignatureException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import io.jsonwebtoken.ExpiredJwtException;

@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

	private static Logger logger = LoggerFactory.getLogger(JwtAuthenticationFilter.class);

	
	@Autowired
	private UserDetailsServiceImpl userDetailsServiceImpl;
	
	@Autowired
	private JwtUtils jwtUtil;
	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		final String requestTokenHeader = request.getHeader("Authorization");
		logger.info("Req Token Header : "+requestTokenHeader);
		String username = null;
		String jwtToken = null;
		if(requestTokenHeader != null && requestTokenHeader.startsWith("Bearer ")) {
			logger.info("IF Condition of JWTAuthenticationFilter is running \t RequestToken header is not null");
			jwtToken = requestTokenHeader.substring(7);
			try {
				username = this.jwtUtil.extractUsername(jwtToken);
				logger.info("Username : in try block :  "+username);
			}catch (ExpiredJwtException e) {
				e.printStackTrace();
				logger.error("Error Occured.");
			}catch (SignatureException e){
//				System.out.println("JWT TOKEN have been modified please provide the valid Token");
//				e.printStackTrace();
//				logger.error("JWT TOKEN have been modified please provide the valid Token");
				throw new UserDefinedException("JWT TOKEN have been modified please provide the valid Token");
			}
		}else {
			logger.info("Else RequestToken header is null Condition of JWTAuthenticationFilter is running");
			logger.info("Token is not starting with Bearer String , INVALID_TOKEN");
		}
		
		//validate
		if(username != null && SecurityContextHolder.getContext().getAuthentication() == null) {
			logger.info("Executing if user == null block:  "+username);
			//send rest request and fetch User info using emailId

			final UserDetails userDetails = this.userDetailsServiceImpl.loadUserByUsername(username);
			if(this.jwtUtil.validateToken(jwtToken, userDetails)){
				//Token is valid
				UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(userDetails, null,userDetails.getAuthorities());
				authenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
				
				SecurityContextHolder.getContext().setAuthentication(authenticationToken);
			}
		}else {
			logger.info("Executing if else == null block:  "+username);
			logger.error("Token is not valid");
		}
		filterChain.doFilter(request, response);
		
	}

}

