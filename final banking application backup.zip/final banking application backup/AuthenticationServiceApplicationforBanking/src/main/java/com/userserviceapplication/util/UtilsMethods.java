package com.userserviceapplication.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;

public class UtilsMethods {
	
	public UtilsMethods() {
		System.out.println("UtilsMethod CLass object is created");
	}

	

	// For Current time in string format
	public String getCurrentTime() {
		LocalDateTime now = LocalDateTime.now();
		// System.out.println("Before Formatting: " + now);
		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
		String formatDateTime = now.format(format);
		return formatDateTime;
	}

	
	public String getCurrentDateInYMD() {
		LocalDateTime now = LocalDateTime.now();
		// System.out.println("Before Formatting: " + now);
		DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String formatDateTime = now.format(format);
		return formatDateTime;
	}

	// For Current time in string format
	public String getCurrentDate() {
		LocalDateTime now = LocalDateTime.now();
		// System.out.println("Before Formatting: " + now);
		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd MMM. yyyy  hh:mm a");
		String formatDateTime = now.format(format);
		//System.out.println(formatDateTime);
		return formatDateTime;
	}

}