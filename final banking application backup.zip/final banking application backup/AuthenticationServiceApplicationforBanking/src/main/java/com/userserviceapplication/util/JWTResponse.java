package com.userserviceapplication.util;

import lombok.Data;

@Data
public class JWTResponse {
    private String token;

}
