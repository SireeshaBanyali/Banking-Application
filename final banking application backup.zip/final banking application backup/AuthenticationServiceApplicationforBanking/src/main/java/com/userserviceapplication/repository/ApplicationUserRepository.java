package com.userserviceapplication.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.userserviceapplication.entity.ApplicationUsers;



public interface ApplicationUserRepository extends JpaRepository<ApplicationUsers, Integer>{
	ApplicationUsers findByUserName(String userName);
	ApplicationUsers findByUserNameAndPassword(String userName,String password);
	List<ApplicationUsers> findByEmpRole(String empRole);
}
