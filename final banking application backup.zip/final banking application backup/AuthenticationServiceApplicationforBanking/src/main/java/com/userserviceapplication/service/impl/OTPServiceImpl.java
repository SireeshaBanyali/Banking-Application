package com.userserviceapplication.service.impl;


import com.userserviceapplication.client.User;
import com.userserviceapplication.config.JwtUtils;
import com.userserviceapplication.entity.OTPData;
import com.userserviceapplication.repository.OTPDataRepository;
import com.userserviceapplication.services.OTPService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@Service
public class OTPServiceImpl implements OTPService {
    @Autowired
    private OTPDataRepository otpDataRepository;

    @Autowired
    private JwtUtils jwtUtils;


    @Autowired
    private RestTemplate restTemplate;

    public OTPData save(OTPData OtpData){
        return otpDataRepository.save(OtpData);
    }

    public boolean validateOtp(int otp,String emailId){
        boolean status = false;
        OTPData otpData =otpDataRepository.getLatestOtp(emailId);
        System.out.println(otpData.getOtp() + " " + otpData.getEmailId() + " " + otpData.getExpiryTime());
        SimpleDateFormat obj = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try
        {
            Date expiry_time = obj.parse(otpData.getExpiryTime());
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date date = new Date();
            System.out.println(formatter.format(date));
            int diff = expiry_time.compareTo(date);
            if(date.before(expiry_time) && otp == otpData.getOtp()) {
                status =true;
            }
            else{
                status = false;
            }
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }

        return status;
    }

    public String validateJWTToken(String token){
        String extractedUsername = this.jwtUtils.extractUsername(token);
        //Rest call to fetch the User Obj for ExtractedUserName
        String endpoint = "http://localhost:9072/user/fetch/user_details/by_user_name/"+extractedUsername;
            ResponseEntity<User> user=restTemplate.getForEntity(endpoint,User.class);
            System.out.println(user);
        System.out.println("Extracted Username : "+extractedUsername);
        Boolean validateToken = this.jwtUtils.validateToken(token,user.getBody().getEmailId());

        return validateToken ? "TOKEN IS VALID":"INVALID TOKEN";
    }
}

