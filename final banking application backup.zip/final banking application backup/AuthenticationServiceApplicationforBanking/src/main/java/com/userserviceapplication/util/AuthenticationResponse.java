package com.userserviceapplication.util;

import lombok.Data;

@Data
public class AuthenticationResponse {
    private String guid;
    private int otp;
    private String validTill;

}
