
package com.userserviceapplication.controller;

import java.util.HashSet;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.userserviceapplication.entity.Role;
import com.userserviceapplication.entity.User;
import com.userserviceapplication.entity.UserRole;
import com.userserviceapplication.service.impl.UserServiceImpl;


@RestController
//@RequestMapping("/user")
@CrossOrigin("*")
public class UserController {
	private static Logger logger = LoggerFactory.getLogger(UserController.class);

	@Autowired
	private UserServiceImpl userServiceImpl;
	

	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;

	@PostMapping("/create")
	public ResponseEntity<User> createUser(@RequestBody User user) {
		//logger.info("=========password in AuthController ================" + user.getPassword());

		//logger.info("=========Username in AuthController ================" + user.getUserName());
		String password = bCryptPasswordEncoder.encode(user.getPassword());
		//logger.info("=========password in AuthController After Encryption ================" + password);

		// encoding password
		user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
		Role role = new Role();
		role.setRoleName("admin");

		Set<UserRole> userRoles = new HashSet<>();
		UserRole ur = new UserRole();
		ur.setRole(role);
		ur.setUser(user);
		userRoles.add(ur);
		logger.info("========= User Object In Controller================" + user);
		logger.info("========= Role Object In Controller================" + ur);
		logger.info("========= User Roles In Controller================" + userRoles);

		User savedUser = this.userServiceImpl.saveUser(user, userRoles);

		return ResponseEntity.ok(savedUser);
	}

	@GetMapping("/find/{userName}")
	public ResponseEntity<User> findUser(@PathVariable String userName) {

		User user = this.userServiceImpl.getUserByUserName(userName);
		return ResponseEntity.ok(user);
	}

	@GetMapping("/testing/application")
	public ResponseEntity<String> testingApplication() {
		return ResponseEntity.ok("Welcome to Insurance Application");
	}
	
}
