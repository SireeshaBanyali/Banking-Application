package com.userserviceapplication.entity;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UserLoginDetailsTest {

    @Test
    void testGetEmail() {
        String email = "test@example.com";
        UserLoginDetails user = new UserLoginDetails(email, "password");
        assertEquals(email, user.getEmail());
    }
    @Test
    void testGetPassword() {
        String password = "password";
        UserLoginDetails user = new UserLoginDetails("test@example.com", password);
        assertEquals(password, user.getPassword());
    }

    @Test
    void testNotEquals() {
        UserLoginDetails user1 = new UserLoginDetails("test@example.com", "password");
        UserLoginDetails user2 = new UserLoginDetails("other@example.com", "password");
        UserLoginDetails user3 = new UserLoginDetails("test@example.com", "other");
        assertNotEquals(user1, user2);
        assertNotEquals(user1, user3);
        assertNotEquals(user2, user3);
    }

}