package com.userserviceapplication.service.impl;

import com.userserviceapplication.entity.OTPData;
import com.userserviceapplication.repository.OTPDataRepository;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

class OTPServiceImplTest {
    @Mock
    private OTPDataRepository otpDataRepository;

    private OTPServiceImpl otpService;



}