package com.userserviceapplication.entity;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class OTPDataTest {

    @Test
    public void testSetOTP() {
        OTPData otpData = new OTPData(123456, "2023-04-17 12:00:00", "test@example.com");
        int expectedOTP = 654321;
        otpData.setOtp(expectedOTP);
        int actualOTP = otpData.getOtp();
        assertEquals(expectedOTP, actualOTP);
    }

    @Test
    public void testSetExpiryTime() {
        OTPData otpData = new OTPData(123456, "2023-04-17 12:00:00", "test@example.com");
        String expectedExpiryTime = "2023-04-18 12:00:00";
        otpData.setExpiryTime(expectedExpiryTime);
        String actualExpiryTime = otpData.getExpiryTime();
        assertEquals(expectedExpiryTime, actualExpiryTime);
    }

    @Test
    public void testSetEmailId() {
        OTPData otpData = new OTPData(123456, "2023-04-17 12:00:00", "test@example.com");
        String expectedEmailId = "test2@example.com";
        otpData.setEmailId(expectedEmailId);
        String actualEmailId = otpData.getEmailId();
        assertEquals(expectedEmailId, actualEmailId);
    }



}