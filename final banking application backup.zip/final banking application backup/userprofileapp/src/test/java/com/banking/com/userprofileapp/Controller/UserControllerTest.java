package com.banking.com.userprofileapp.Controller;

import com.banking.com.userprofileapp.Model.DataForUser;
import com.banking.com.userprofileapp.Model.ErrorClass;
import com.banking.com.userprofileapp.Model.User;
import com.banking.com.userprofileapp.Model.UserResponse;
import com.banking.com.userprofileapp.ServiceImpl.UserServiceImpl;
import com.banking.com.userprofileapp.exception.UserDefinedException;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class UserControllerTest {

    @Mock
    private UserServiceImpl userService;

    private UserController userController;

    UserServiceImpl service=new UserServiceImpl() ;

    UserController controller=mock(UserController.class);

    @Test
    public void testUserRegistration_Success() throws UserDefinedException {
        User user = new User();
        user.setEmailId("Sireesha@gmail.com");
        user.setPassword("siri@123");
        user.setFirst_name("Sireesha");
        DataForUser data=new DataForUser();
        data.setUser_id(1);

        ErrorClass error=new ErrorClass();
        error.setCode(null);
        error.setMessage(null);

        UserResponse response=new UserResponse("success",data,error);
        assertNotNull(response);


    }


}