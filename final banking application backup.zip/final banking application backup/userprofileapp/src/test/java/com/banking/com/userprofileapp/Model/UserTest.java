package com.banking.com.userprofileapp.Model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UserTest {

    @Test
    void testGetFirstName() {
        String firstName = "John";
        User user = new User();
        user.setFirst_name(firstName);
        assertEquals(firstName, user.getFirst_name());
    }
    @Test
    void testGetPhoneNumber() {
        long phoneNumber = 1234567890;
        User user = new User();
        user.setPhone_number(phoneNumber);
        assertEquals(phoneNumber, user.getPhone_number());
    }

    @Test
    void testGetPanNumber() {
        String panNumber = "ABCD1234E";
        User user = new User();
        user.setPan_number(panNumber);
        assertEquals(panNumber, user.getPan_number());
    }

    @Test
    void testGetPassword() {
        String password = "password123";
        User user = new User();
        user.setPassword(password);
        assertEquals(password, user.getPassword());
    }

}