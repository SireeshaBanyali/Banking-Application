package com.banking.com.userprofileapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserprofileappApplicationTests {

	@Test
	void contextLoads() {
	}

}
