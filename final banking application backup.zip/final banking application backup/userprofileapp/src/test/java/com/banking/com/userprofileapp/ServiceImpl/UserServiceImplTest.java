package com.banking.com.userprofileapp.ServiceImpl;

import com.banking.com.userprofileapp.Model.User;
import com.banking.com.userprofileapp.Model.UserResponse;
import com.banking.com.userprofileapp.exception.UserDefinedException;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

class UserServiceImplTest {
    UserServiceImpl userServiceImple=mock(UserServiceImpl.class);






}