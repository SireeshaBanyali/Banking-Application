package com.banking.com.userprofileapp.Model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AddressTest {

    Address ad=new Address();
    User user=new User();
    @Test
    public void userTest(){
        user.setPhone_number(Long.parseLong("9866243296"));
        user.setEmailId("Sireesha@gmail.com");
        user.setPassword("siri@gmail.com");
        assertNotNull(user);
    }

    @Test
    public void addressTest(){
        assertNotNull(ad);
    }

}