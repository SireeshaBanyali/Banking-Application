package com.banking.com.userprofileapp.client;

import com.banking.com.userprofileapp.Service.UserService;
import org.aspectj.lang.annotation.Before;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.web.client.RestTemplate;


import static org.hamcrest.Matchers.any;


import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

class Account_clientTest {

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private UserService userAccountService;

    private UserAccount request;



}