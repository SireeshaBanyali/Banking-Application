package com.banking.com.userprofileapp.client;

import lombok.Data;

@Data
public class UserAccount {
    private String accountNumber;
    private String userName;
    private double currentBalance;
}
