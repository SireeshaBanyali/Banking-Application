package com.banking.com.userprofileapp.Model;


import lombok.Data;

@Data
public class DataForUser {
    private int user_id;

}
