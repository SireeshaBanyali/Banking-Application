package com.banking.com.userprofileapp.Controller;

import com.banking.com.userprofileapp.Model.User;
import com.banking.com.userprofileapp.Model.UserResponse;
import com.banking.com.userprofileapp.ServiceImpl.UserServiceImpl;
import com.banking.com.userprofileapp.exception.UserDefinedException;
import com.banking.com.userprofileapp.utils.CommonMethods;
import com.banking.com.userprofileapp.utils.LoginRequest;
import com.banking.com.userprofileapp.utils.UpdateUserProfile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;


@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
  private UserServiceImpl userServiceImple;

    @Autowired
    private RestTemplate restTemplate;
    CommonMethods commonMethods=new CommonMethods();

    @PostMapping("/registration")
    public ResponseEntity<UserResponse> UserRegistration(@RequestBody User users){
        return new ResponseEntity<UserResponse>(userServiceImple.createUser(users), HttpStatus.CREATED);

    }
    @GetMapping("/getAllUsers")
    public ResponseEntity<Object> getUserDetails(@RequestHeader("Authorization") String jwtToken) {

        System.out.println(jwtToken);
        List<User> usersList = new ArrayList<>();
        ResponseEntity<String> token = commonMethods.validateJwtToken(jwtToken);
        System.out.println(token);
        if(token.getStatusCodeValue()==401){
            return new ResponseEntity<>("token is invalid",HttpStatus.UNAUTHORIZED);
        }else{
            usersList = this.userServiceImple.getAllUsers();
            return new ResponseEntity<>(usersList,HttpStatus.OK);

        }

    }


    @PostMapping("/fetch/user")
    public ResponseEntity<User> fetchUser(@RequestBody LoginRequest loginRequest){
        User user = this.userServiceImple.fetchUser(loginRequest.getEmailId(), loginRequest.getPassword());
        return ResponseEntity.ok(user);
    }
    @GetMapping("/fetch/user_details/by_user_name/{userName}")
    public ResponseEntity<User> fetchUserByUserName(@PathVariable String userName){
        User user = this.userServiceImple.fetchUserByEmailID(userName);
        return ResponseEntity.ok(user);
    }



    @PutMapping("/updateProfile")
    public ResponseEntity<Object> updateProfile(@RequestBody User user,@RequestHeader("Authorization") String jwtToken){

        ResponseEntity<String> token = commonMethods.validateJwtToken(jwtToken);
        System.out.println(token);
        if(token.getStatusCodeValue()==401){
            return new ResponseEntity<>("token is invalid ⌛⌛",HttpStatus.UNAUTHORIZED);
        }else{
            UserResponse users=userServiceImple.updateProfile(user);
            return new ResponseEntity<>(users,HttpStatus.OK);

        }

    }



    @PutMapping("changePassword")
    public ResponseEntity<String> changePassword(@RequestBody LoginRequest loginRequest,@RequestHeader("Authorization") String jwtToken){

        ResponseEntity<String> token = commonMethods.validateJwtToken(jwtToken);
        System.out.println(token);
        if(token.getStatusCodeValue()==401){
            return new ResponseEntity<>("token is invalid",HttpStatus.UNAUTHORIZED);
        }else{
            userServiceImple.changePassword(loginRequest);
            return new ResponseEntity<String>("password changed successfully 🎉🎉",HttpStatus.OK);

        }
    }

    @GetMapping("/tokenvalidation")
    public ResponseEntity<String> validateToken(@RequestHeader("Authorization") String jwtToken) {
        // try {
        ResponseEntity<String> token = commonMethods.validateJwtToken(jwtToken);
        if (token.getStatusCodeValue() == 401) {
            return new ResponseEntity<>("token is invalid", HttpStatus.UNAUTHORIZED);
        } else {
            return new ResponseEntity<>("TOKEN VALID", HttpStatus.OK);
        }

    }





}
