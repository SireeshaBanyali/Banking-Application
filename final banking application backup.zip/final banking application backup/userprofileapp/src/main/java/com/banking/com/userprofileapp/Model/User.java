package com.banking.com.userprofileapp.Model;


import jakarta.persistence.*;
import lombok.*;

import java.sql.Date;


@Entity
@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@Data
public class User   {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int userId;
    private String first_name;
    private String last_Name;
    private long phone_number;
    private Date date_Of_Birth;
    private String pan_number;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "perminentaddress_id", referencedColumnName = "id")
    private Address permanentAddress;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "currentaddress_id", referencedColumnName = "id")
    private Address currentAddress;
    private String gender;
    private String emailId;
    private String password;


   private String accountNumber;




}
