package com.banking.com.userprofileapp.ServiceImpl;

import com.banking.com.userprofileapp.Model.Address;
import com.banking.com.userprofileapp.Model.DataForUser;
import com.banking.com.userprofileapp.Model.User;
import com.banking.com.userprofileapp.Model.UserResponse;
import com.banking.com.userprofileapp.Repository.UserRepository;
import com.banking.com.userprofileapp.Service.UserService;
import com.banking.com.userprofileapp.client.AccountClient;
import com.banking.com.userprofileapp.client.UserAccount;
import com.banking.com.userprofileapp.exception.UserDefinedException;
import com.banking.com.userprofileapp.utils.JWTUser;
import com.banking.com.userprofileapp.utils.LoginRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDate;
import java.time.Period;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Pattern;


@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AccountClient accountClient;
    @Autowired
    private RestTemplate restTemplate;

    public UserResponse createUser(User user){
        /*if(user.getFirst_name()==null){
            throw new UserDefinedException("firstName is the required field,please enter the firstName");
        }*/
        if(Objects.isNull(user.getLast_Name()) || !Pattern.matches("^[a-zA-Z']+$", user.getLast_Name())) {
            throw new UserDefinedException("invalid Last name");
        }
        if(user.getPan_number()==null){
            throw new UserDefinedException("panNumber is the required field,please enter the panNumber🤦🏻‍♀️🤦🏻‍♀️");
        }

        String regex="[A-Z]{5}[0-9]{4}[A-Z]{1}$";
        if(!user.getPan_number().matches(regex)){
            throw new UserDefinedException("PAN CARD NUBER WAS MISMATCH🧐");
        }
        User account=userRepository.findByEmailId(user.getEmailId());
        if(account!=null){
            throw new UserDefinedException("user already registered👩🏻");
        }


        if(Objects.isNull(user.getEmailId()) || !Pattern.matches("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+.[A-Za-z]{2,6}", user.getEmailId())) {
            throw new UserDefinedException("invalid Email");
        }


        LocalDate startDate = user.getDate_Of_Birth().toLocalDate();
        LocalDate today = LocalDate.now();
        int age = Period.between(startDate, today).getYears();
        if(age<18) {
            throw new UserDefinedException("age should be greater than 18");
        }

        if(Objects.isNull(user.getPhone_number()) || String.valueOf(user.getPhone_number()).length()!=10) {
            throw new UserDefinedException("invalid phoneNumber");
        }





        System.out.println("======================================================");
        System.out.println(user);
        System.out.println("======================================================");

        JWTUser jwtUser = new JWTUser();
        jwtUser.setFirstName(user.getFirst_name());
        jwtUser.setLastName(user.getLast_Name());
        jwtUser.setContactNumber(String.valueOf(user.getPhone_number()));
        jwtUser.setEmail(user.getEmailId());
        jwtUser.setCity(user.getCurrentAddress().getCity());
        jwtUser.setUserName(user.getEmailId());
        jwtUser.setPassword(user.getPassword());

        String endpoint="http://localhost:9081/create";
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        Map<String, String> requestBody = new HashMap<>();
        requestBody.put("firstName",jwtUser.getFirstName() );
        requestBody.put("lastName", jwtUser.getLastName());
        requestBody.put("contactNumber",jwtUser.getContactNumber());
        requestBody.put("email",jwtUser.getEmail());

        if(jwtUser.getContactNumber().length()!=10){
            throw new UserDefinedException("invalid phone number the number shoud be contains 10 digits🤦🏻‍♀️");
        }
        requestBody.put("city",jwtUser.getCity());
        requestBody.put("about","User of ABC bank");
        requestBody.put("profile","Something");
        requestBody.put("userName",jwtUser.getUserName());
        requestBody.put("password",jwtUser.getPassword());


        HttpEntity<Map<String, String>> requestEntity = new HttpEntity<>(requestBody, headers);
        ResponseEntity<JWTUser> response = restTemplate.postForEntity(endpoint, requestEntity, JWTUser.class);
        JWTUser responseBody = response.getBody();

        System.out.println(responseBody);
        UserAccount accounts=new UserAccount();
        accounts.setUserName(user.getEmailId());
        UserAccount ac=accountClient.createAccount(accounts);
        user.setAccountNumber(ac.getAccountNumber());



        User users=userRepository.save(user);
        UserResponse responses=new UserResponse();
        DataForUser data=new DataForUser();
        data.setUser_id(user.getUserId());
        responses.setData(data);
        responses.setStatus("success");
        return responses;

    }

    public List<User> getAllUsers(){
        return userRepository.findAll();
    }


    @Override
    public User fetchUser(String emailId, String password) {

        User user = this.userRepository.findByEmailIdAndPassword(emailId, password);
        return user;
    }

    public User fetchUserByEmailID(String emailId) {
        User user = this.userRepository.findByEmailId(emailId);
        return user;
    }

    public void changePassword(LoginRequest loginRequest) {
        User user=userRepository.findByEmailId(loginRequest.getEmailId());
        if(user==null){
            throw new UserDefinedException("you entered wrong userName and password🖊️");
        }
        if(loginRequest.getPassword().equals(user.getPassword())){
            throw new UserDefinedException("existed password and new password are same🔍");
        }
        user.setPassword(loginRequest.getPassword());

        userRepository.save(user);


    }

    public UserResponse updateProfile(User user) {
        User users=userRepository.findByEmailId(user.getEmailId());
        if(users==null){
            throw new UserDefinedException("does not having account with this account number 🙆‍♀️🙆‍♀️");
        }

        users.setFirst_name(user.getFirst_name());
        users.setLast_Name(user.getLast_Name());
        if(Objects.isNull(user.getLast_Name()) || !Pattern.matches("^[a-zA-Z']+$", user.getLast_Name())) {
            throw new UserDefinedException("invalid Last name");
        }
        users.setDate_Of_Birth(user.getDate_Of_Birth());
        LocalDate startDate = user.getDate_Of_Birth().toLocalDate();
        LocalDate today = LocalDate.now();
        int age = Period.between(startDate, today).getYears();
        if(age<18) {
            throw new UserDefinedException("age should be greater than 18");
        }
        users.setGender(user.getGender());
        users.setPan_number(user.getPan_number());
        if(user.getPan_number()==null){
            throw new UserDefinedException("panNumber is the required field,please enter the panNumber🤦🏻‍♀️🤦🏻‍♀️");
        }

        String regex="[A-Z]{5}[0-9]{4}[A-Z]{1}$";
        if(!user.getPan_number().matches(regex)){
            throw new UserDefinedException("PAN CARD NUBER WAS MISMATCH🧐");
        }
        users.setPhone_number(user.getPhone_number());
        if(Objects.isNull(user.getPhone_number()) || String.valueOf(user.getPhone_number()).length()!=10) {
            throw new UserDefinedException("invalid phoneNumber");
        }

        users.setCurrentAddress(users.getCurrentAddress());
        users.setPermanentAddress(user.getPermanentAddress());

        user.setAccountNumber(users.getAccountNumber());

           userRepository.save(users);
        UserResponse resp=new UserResponse();
        DataForUser data=new DataForUser();
        data.setUser_id(users.getUserId());
        resp.setStatus("Success");
        resp.setError(null);
        resp.setData(data);
        return resp;

    }





}

