package com.banking.com.userprofileapp.Repository;

import com.banking.com.userprofileapp.Model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<User,Integer> {
    User findByEmailIdAndPassword(String emailId, String password);

    @Query(value="select * from user where account_number=?",nativeQuery = true)
    public  User findbyAccountNumber(String accountNumber);
    User findByEmailId(String emailId);
}
