package com.banking.com.userprofileapp.Model;

import lombok.*;

@Setter
@Getter
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserResponse {

    private String status;
    private DataForUser data;
    private ErrorClass Error;


}
