package com.banking.com.userprofileapp.Model;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
public class Address {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String door_number;
    private String street;
    private String area;
    private String city;
    private String state;
    private String state_Code;
    private long pin_code;

}
