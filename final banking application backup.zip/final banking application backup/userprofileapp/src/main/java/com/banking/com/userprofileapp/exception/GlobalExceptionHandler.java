package com.banking.com.userprofileapp.exception;

import com.banking.com.userprofileapp.Model.ErrorClass;
import com.banking.com.userprofileapp.Model.ErrorResponseClass;
import com.banking.com.userprofileapp.Model.UserResponse;
import com.banking.com.userprofileapp.client.ClientModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {
    ClientModel response = new ClientModel();
    @ExceptionHandler(UserDefinedException.class)
    public ResponseEntity<UserResponse> userDefinedExceptionHandler(UserDefinedException ex){

        UserResponse response=new UserResponse();
        response.setStatus("failed");
        ErrorClass error=new ErrorClass();
        error.setCode("1001");
        error.setMessage(ex.getMessage());
        response.setError(error);

        return new ResponseEntity<UserResponse>(response, HttpStatus.BAD_REQUEST);

    }


}
