package com.banking.com.userprofileapp.Service;

import com.banking.com.userprofileapp.Model.User;
import com.banking.com.userprofileapp.Model.UserResponse;

import java.util.List;

public interface UserService {
    public UserResponse createUser(User users);
    public List<User> getAllUsers();
    public User fetchUser(String emailId, String password);
    public User fetchUserByEmailID(String emailId);
}
