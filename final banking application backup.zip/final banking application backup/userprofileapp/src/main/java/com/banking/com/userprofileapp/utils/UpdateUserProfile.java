package com.banking.com.userprofileapp.utils;

import lombok.Data;

import java.util.Date;

@Data
public class UpdateUserProfile {
    private String first_name;
    private String last_Name;
    private long phone_number;
    private Date date_Of_Birth;
    private String pan_number;

    private String jwtToken;
}
