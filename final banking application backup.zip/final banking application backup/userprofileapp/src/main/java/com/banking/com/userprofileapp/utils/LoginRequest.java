package com.banking.com.userprofileapp.utils;

import jakarta.persistence.Transient;
import lombok.Data;

@Data
public class LoginRequest {
    private String emailId;
    private String password;


}
