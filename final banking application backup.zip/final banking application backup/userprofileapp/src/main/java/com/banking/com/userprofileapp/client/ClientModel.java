package com.banking.com.userprofileapp.client;

import com.banking.com.userprofileapp.Model.ErrorResponseClass;
import lombok.Data;

@Data
public class ClientModel {
    private String status;
    private  String data;
    private ErrorResponseClass error;
}
