package com.banking.com.userprofileapp.Model;

import lombok.Data;

@Data
public class ErrorResponseClass {
    private String code;
    private String message;
}
