package com.banking.com.userprofileapp.utils;

import lombok.Data;

@Data
public class JWTUser {
    private String firstName;

    private String lastName;
    private String contactNumber;
    private String email;
    private String city;
    private String about;
    private String profile;
    private String userName;
    private String password;
}
