package com.banking.com.userprofileapp.client;

import com.banking.com.userprofileapp.Model.User;
import com.banking.com.userprofileapp.exception.UserDefinedException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

@Component
public class AccountClient {

    @Autowired
    private RestTemplate restTemplate;

    public ResponseEntity<UserAccount> getUserAccount(User users) {
        String AccountNumber = users.getAccountNumber();
        ResponseEntity<UserAccount> user=null;
try {
    String endPoint = "http://localhost:8095/account/getUserByAccountNumber/{AccountNumber}";
    user = restTemplate.getForEntity(endPoint, UserAccount.class, AccountNumber);
    System.out.println(user);
    return user;
}catch(Exception e){
    String code = e.getMessage().substring(0, 3);
    if(!code.equalsIgnoreCase("200")){
        throw new UserDefinedException("no account found");
    }
}

            return null;
        }
    public UserAccount createAccount(@RequestBody UserAccount request) {
        // try {
        HttpHeaders headers = new HttpHeaders();
        Map<String, String> mp = new HashMap<>();
        mp.put("userName", request.getUserName());
        HttpEntity<Object> model = new HttpEntity<Object>(mp, headers);
        String endPoint = "http://localhost:8095/account/createUserAccount";
        UserAccount user = null;
        user = restTemplate.exchange(endPoint, HttpMethod.POST, model, UserAccount.class).getBody();

        return user;
    }


    public UserAccount getAccountByUserName(String user) {
        String email = user;
        ResponseEntity<UserAccount> users = null;
        try {
            String endPoint = "http://localhost:8095/account/getAccoutByUserName/email";
            users = restTemplate.getForEntity(endPoint, UserAccount.class, email);
            System.out.println(user);
            return users.getBody();
        } catch (Exception e) {
            String code = e.getMessage().substring(0, 3);
            if (!code.equalsIgnoreCase("200")) {
                throw new UserDefinedException("no account found");
            }
        }

        return null;



    }



    }


