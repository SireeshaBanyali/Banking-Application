package com.banking.com.userprofileapp.exception;

import org.springframework.web.bind.ServletRequestBindingException;

public class MissingRequestHeaderException extends ServletRequestBindingException {
    private final String headerName;

    public MissingRequestHeaderException(String headerName) {
        super("Required request header '" + headerName + "' is not present");
        this.headerName = headerName;
    }

    public String getHeaderName() {
        return this.headerName;
    }
}
