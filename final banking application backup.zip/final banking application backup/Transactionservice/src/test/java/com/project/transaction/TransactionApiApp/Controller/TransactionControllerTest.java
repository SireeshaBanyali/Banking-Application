package com.project.transaction.TransactionApiApp.Controller;

import com.project.transaction.TransactionApiApp.Exceptions.UserDefinedException;
import com.project.transaction.TransactionApiApp.client.AccountSummery;
import com.project.transaction.TransactionApiApp.common.CommonMethods;
import com.project.transaction.TransactionApiApp.entity.FetchRequest;
import com.project.transaction.TransactionApiApp.entity.FundTransferRequest;
import com.project.transaction.TransactionApiApp.entity.TransactionRequest;
import com.project.transaction.TransactionApiApp.service.TransactionService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

class TransactionControllerTest {
    @Mock
    private TransactionController controller;
    @Mock
    private TransactionService service;
    @Mock
    private CommonMethods commonMethods;
    private String validToken;

    private AccountSummery accountSummery;

    private String jwtToken;

    private TransactionRequest request;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        jwtToken = "valid_jwt_token";
        request = new TransactionRequest("Dp", 100.0);
    }
    @Test
    void testDepositAmountSuccess() {
        // given
        ResponseEntity<String> token = new ResponseEntity<>("TOKEN IS VALID", HttpStatus.OK);
        when(commonMethods.validateJwtToken(jwtToken)).thenReturn(token);
        ResponseEntity<Object> expectedResult = new ResponseEntity<>("success", HttpStatus.OK);
        when(service.depositAmount(jwtToken, request)).thenReturn(expectedResult);

        // when
        ResponseEntity<Object> actualResult = controller.DepositeAndwithdrawAmount(jwtToken, request);

        // then
        assertNotEquals(expectedResult, actualResult);
    }

    @Test
    void testWithdrawAmountSuccess() {
        // given
        ResponseEntity<String> token = new ResponseEntity<>("valid", HttpStatus.OK);
        when(commonMethods.validateJwtToken(jwtToken)).thenReturn(token);
        request.setType("Wd");
        ResponseEntity<Object> expectedResult = new ResponseEntity<>("success", HttpStatus.OK);
        when(service.withdrawAmount(jwtToken, request)).thenReturn(expectedResult);

        // when
        ResponseEntity<Object> actualResult = controller.DepositeAndwithdrawAmount(jwtToken, request);

        // then
        assertNotEquals(expectedResult, actualResult);
    }

    @Test
    void testInvalidJwtToken() {
        // given
        ResponseEntity<String> token = new ResponseEntity<>("token is invalid", HttpStatus.UNAUTHORIZED);
        when(commonMethods.validateJwtToken(jwtToken)).thenReturn(token);

        // when
        ResponseEntity<Object> actualResult = controller.DepositeAndwithdrawAmount(jwtToken, request);

        // then
        assertEquals(HttpStatus.UNAUTHORIZED,token.getStatusCode());
        assertEquals("token is invalid", token.getBody());
    }



}