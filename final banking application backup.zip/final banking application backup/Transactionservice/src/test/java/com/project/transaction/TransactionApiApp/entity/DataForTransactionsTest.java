package com.project.transaction.TransactionApiApp.entity;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DataForTransactionsTest {

    DataForTransactions transactions=new DataForTransactions();

    @Test
    public void DataTransactionTest(){
        transactions.setType("Dp");
        transactions.setCreditammount(1000);
        transactions.setDebitammount(10);
        transactions.setRemarks("Deposite");
        assertEquals("Dp",transactions.getType());

    }

}