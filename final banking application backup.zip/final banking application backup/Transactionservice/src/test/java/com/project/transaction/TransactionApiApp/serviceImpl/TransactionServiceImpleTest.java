package com.project.transaction.TransactionApiApp.serviceImpl;

import com.project.transaction.TransactionApiApp.Controller.TransactionController;
import com.project.transaction.TransactionApiApp.Repository.TransactionRequestRepository;
import com.project.transaction.TransactionApiApp.client.AccountClient;
import com.project.transaction.TransactionApiApp.entity.TransactionRequest;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.mockito.Mockito.*;

class TransactionServiceImpleTest {
    private AccountClient client = mock(AccountClient.class);

    TransactionRequestRepository repository = mock(TransactionRequestRepository.class);

    TransactionServiceImple service=new TransactionServiceImple();


    @Test
    void testDepositAmount_withInvalidToken() {
        // Set up test data
        String jwtToken = "invalidToken";
        TransactionRequest request = new TransactionRequest();
        request.setAmount(100.0);
        when(client.depositAmmount(jwtToken, request)).thenReturn(new ResponseEntity<>(HttpStatus.UNAUTHORIZED));
        TransactionController controller = mock(TransactionController.class);

        // Call the method being tested
        //ResponseEntity<Object> response = controller.DepositeAndwithdrawAmount(jwtToken, request);

        // Verify the results
        //assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        //assertNull(response.getBody());

        // Verify that the deposit was not saved to the repository
        verify(repository, never()).save(request);
    }
    @Test
    void testWithdrawAmount_withInvalidToken() {
        // Set up test data
        String jwtToken = "invalidToken";
        TransactionRequest request = new TransactionRequest();
        request.setAmount(100.0);
        when(client.withdrawAmmount(jwtToken, request)).thenReturn(new ResponseEntity<>(HttpStatus.UNAUTHORIZED));
        TransactionController controller = mock(TransactionController.class);

        // Call the method being tested
        //ResponseEntity<Object> response = controller.DepositeAndwithdrawAmount(jwtToken, request);

        // Verify the results
        //assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        //assertNull(response.getBody());

        // Verify that the deposit was not saved to the repository
        verify(repository, never()).save(request);
    }


    @Test
    void testWithdrawAmount_withInsufficientFunds() {
        // Set up test data
        String jwtToken = "exampleToken";
        TransactionRequest request = new TransactionRequest();
        request.setAmount(100.0);
        AccountClient client = mock(AccountClient.class);
        when(client.withdrawAmmount(jwtToken, request)).thenReturn(new ResponseEntity<>(HttpStatus.FORBIDDEN));
        //TransactionServiceImple service=new TransactionServiceImple();

        // Call the method being tested
        //
        // ResponseEntity<Object> response = service.withdrawAmount(jwtToken, request);

        // Verify the results
        //assertEquals(HttpStatus.FORBIDDEN, response.getStatusCode());
        //assertNotNull(response.getBody());

        // Verify that the withdrawal was not saved to the repository
        verify(repository, never()).save(request);
    }

    @Test
    void testDeposit_withInsufficientFunds() {
        // Set up test data
        String jwtToken = "exampleToken";
        TransactionRequest request = new TransactionRequest();
        request.setAmount(100.0);
        AccountClient client = mock(AccountClient.class);
        when(client.depositAmmount(jwtToken, request)).thenReturn(new ResponseEntity<>(HttpStatus.FORBIDDEN));
        //TransactionServiceImple service=new TransactionServiceImple();

        // Call the method being tested
        //
        // ResponseEntity<Object> response = service.withdrawAmount(jwtToken, request);

        // Verify the results
        //assertEquals(HttpStatus.FORBIDDEN, response.getStatusCode());
        //assertNotNull(response.getBody());

        // Verify that the withdrawal was not saved to the repository
        verify(repository, never()).save(request);
    }


}