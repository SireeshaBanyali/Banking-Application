package com.project.transaction.TransactionApiApp.entity;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class FetchRequestTest {
    FetchRequest request=new FetchRequest();

    @Test
    public void FetchRequestTest(){
        assertNotNull(request);
    }

    @Test
    public void FetcRequestTest1(){
        request.setUserName("Sireesha");
        assertEquals("Sireesha",request.getUserName());
    }

}