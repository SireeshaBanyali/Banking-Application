package com.project.transaction.TransactionApiApp.serviceImpl;

import com.project.transaction.TransactionApiApp.Repository.TransactionDetailsRepository;
import com.project.transaction.TransactionApiApp.Repository.TransactionRepository;
import com.project.transaction.TransactionApiApp.Repository.TransactionRequestRepository;
import com.project.transaction.TransactionApiApp.client.AccountClient;
import com.project.transaction.TransactionApiApp.client.AccountSummery;
import com.project.transaction.TransactionApiApp.entity.*;
import com.project.transaction.TransactionApiApp.service.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

@Service
public class TransactionServiceImple implements TransactionService {
    @Autowired
    private TransactionRequestRepository transactionRequestRepository;
    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private TransactionDetailsRepository detailRepository;

    @Autowired
    private AccountClient client;

    public ResponseEntity<Object> depositAmount(String jwtToken, TransactionRequest request) {
        ResponseEntity<AccountSummery> accountSummery=client.depositAmmount(jwtToken,request);
        System.out.println("===================================================================");;

        System.out.println("===================================================================");
        request.setAccountNumber(accountSummery.getBody().getAccountNumber());
        request.setDebitAmmount(0.0);
        request.setCreditAmmount(request.getAmount());
        request.setRemarks("Deposit");
        request.setUserName(accountSummery.getBody().getUserName());
        request.setDate(new Date(System.currentTimeMillis()));
        transactionRequestRepository.save(request);

        Transaction tr=new Transaction();
        tr.setRemarks(request.getRemarks());
        tr.setTransactionDate(request.getDate());
        tr.setTransactionType("Dp");
        transactionRepository.save(tr);

        TransactionDetails trd=new TransactionDetails();
        trd.setAccountNumber(request.getAccountNumber());
        trd.setTransactionId(tr.getTransactionId());
        trd.setPostingType("C-Credit");
        trd.setAmount(request.getAmount());
        detailRepository.save(trd);


        TransactionResponse ts=new TransactionResponse();
        DataForTransactions ds=new DataForTransactions();
        ds.setCreditammount(request.getCreditAmmount());
        ds.setDate(new Date(System.currentTimeMillis()));
        ds.setType("Dp");
        ds.setRemarks("Deposit");
        ts.setStatus("success");
        ts.setData(ds);
        ts.setError("null");
        return new ResponseEntity<Object>(ts, HttpStatus.OK);

    }

    public ResponseEntity<Object> withdrawAmount(String jwtToken,TransactionRequest request) {
        ResponseEntity<AccountSummery> accountSummery=client.withdrawAmmount(jwtToken,request);

        request.setAccountNumber(accountSummery.getBody().getAccountNumber());
        request.setCreditAmmount(0.0);
        request.setDebitAmmount(request.getAmount());
        request.setRemarks("Withdraw");
        request.setUserName(accountSummery.getBody().getUserName());
        request.setDate(new Date(System.currentTimeMillis()));
        transactionRequestRepository.save(request);

        Transaction tr=new Transaction();
        tr.setRemarks(request.getRemarks());
        tr.setTransactionDate(request.getDate());
        tr.setTransactionType("Wd");
        transactionRepository.save(tr);


        TransactionDetails trd=new TransactionDetails();
        trd.setAccountNumber(request.getAccountNumber());
        trd.setTransactionId(tr.getTransactionId());
        trd.setPostingType("D-Debit");
        trd.setAmount(request.getAmount());
        detailRepository.save(trd);


        TransactionResponse ts=new TransactionResponse();
        DataForTransactions ds=new DataForTransactions();
        ds.setDebitammount(request.getDebitAmmount());
        ds.setDate(new Date(System.currentTimeMillis()));
        ds.setType("WD");
        ds.setRemarks("with draw");
        ts.setStatus("success");
        ts.setData(ds);
        ts.setError("null");
        return new ResponseEntity<Object>(ts, HttpStatus.OK);

    }
    public ResponseEntity<TransactionResponse> fundTrasaction(String jwtToken,FundTransferRequest request) {
        ResponseEntity<AccountSummery> accountSummery=client.fundTrasactionAmmount(jwtToken,request);
        TransactionRequest request1=new TransactionRequest();
        request1.setAccountNumber(accountSummery.getBody().getAccountNumber());
        request1.setDebitAmmount(request.getAmmount());
        request1.setCreditAmmount(0.0);
        request1.setRemarks("Fund trasaction");
        request1.setType(request.getType());
        request1.setUserName(accountSummery.getBody().getUserName());
        request1.setDate(new Date(System.currentTimeMillis()));
        transactionRequestRepository.save(request1);

        Transaction tr=new Transaction();
        tr.setRemarks(request1.getRemarks());
        tr.setTransactionDate(request1.getDate());
        tr.setTransactionType("Ft");
        transactionRepository.save(tr);


        TransactionDetails trd=new TransactionDetails();
        trd.setAccountNumber(request.getSourceAccountNumber());
        trd.setTransactionId(tr.getTransactionId());
        trd.setPostingType("D-Debit");
        trd.setAmount(request.getAmmount());
        detailRepository.save(trd);

        TransactionDetails trd1=new TransactionDetails();
        trd1.setAccountNumber(request.getBeneficiaryAccountNumber());
        trd1.setTransactionId(tr.getTransactionId());
        trd1.setPostingType("C-Credit");
        trd1.setAmount(request.getAmmount());
        detailRepository.save(trd1);

        TransactionResponse ts=new TransactionResponse();
        DataForTransactions ds=new DataForTransactions();
        ds.setDebitammount(request1.getDebitAmmount());
        ds.setCreditammount(request1.getCreditAmmount());
        ds.setDate(new Date(System.currentTimeMillis()));
        ds.setType("ft");
        ds.setRemarks("fund trasfer");
        ts.setStatus("success");
        ts.setData(ds);
        ts.setError("null");
        return new ResponseEntity<TransactionResponse>(ts,HttpStatus.OK);

    }

    public FetchResponse fetchAllTransactions(FetchRequest request) {
        List<TransactionRequest> ts = transactionRequestRepository.fetchallTransaction(request.getStartDate(), request.getEndDate(),request.getUserName());
        System.out.println(ts);
        FetchResponse response=new FetchResponse();
        response.setStatus("success");
        List<DataForTransactions> dataforList=new ArrayList<DataForTransactions>();

        for(TransactionRequest requests:ts){
            DataForTransactions dt= new DataForTransactions();
            dt.setRemarks(requests.getRemarks());
            dt.setType(requests.getType());
            dt.setDate(requests.getDate());
            dt.setCreditammount(requests.getCreditAmmount());
            dt.setDebitammount(requests.getDebitAmmount());
            dataforList.add(dt);

            response.setData(dataforList);
            response.setError("null");
        }
        return  response;
    }









}
