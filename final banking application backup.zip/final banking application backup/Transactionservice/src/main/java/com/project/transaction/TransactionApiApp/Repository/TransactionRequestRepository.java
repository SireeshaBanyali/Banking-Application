package com.project.transaction.TransactionApiApp.Repository;

import com.project.transaction.TransactionApiApp.entity.TransactionRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.sql.Date;
import java.util.List;

@Repository
public interface TransactionRequestRepository extends JpaRepository<TransactionRequest, String> {

    @Query(value = "SELECT * FROM transaction_request WHERE date BETWEEN ? AND ? AND user_name=?",nativeQuery = true)
    public List<TransactionRequest> fetchallTransaction(Date startDate, Date endDate, String userName);


}
