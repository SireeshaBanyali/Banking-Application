package com.project.transaction.TransactionApiApp.Repository;

import com.project.transaction.TransactionApiApp.entity.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TransactionRepository extends JpaRepository<Transaction,Integer> {
}
