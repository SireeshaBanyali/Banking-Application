package com.project.transaction.TransactionApiApp.service;

import com.project.transaction.TransactionApiApp.entity.*;
import org.springframework.http.ResponseEntity;

public interface TransactionService {
    public ResponseEntity<Object> depositAmount(String jwtToken, TransactionRequest request);
    public ResponseEntity<Object> withdrawAmount(String jwtToken,TransactionRequest request);
    public ResponseEntity<TransactionResponse> fundTrasaction(String jwtToken, FundTransferRequest request);
    public FetchResponse fetchAllTransactions(FetchRequest request);
}
