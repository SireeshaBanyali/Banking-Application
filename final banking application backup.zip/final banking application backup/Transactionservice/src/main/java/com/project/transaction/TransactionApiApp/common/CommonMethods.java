package com.project.transaction.TransactionApiApp.common;

import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class CommonMethods {
    public ResponseEntity<String> validateJwtToken(String jwtToken) {
        try {
            System.out.println("Executing the validateJwtToken method");
            String response = "Received JWT Token is : " + jwtToken;
            HttpHeaders headers = new HttpHeaders();
            RestTemplate restTemplate = new RestTemplate();
//        headers.set("Authorization", jwtToken);
            headers.set("Authorization", "Bearer " + jwtToken);
            String endpoint = "http://localhost:9081/validate-token/" + jwtToken;
            HttpEntity<?> httpEntity = new HttpEntity<>(null, headers);
            ResponseEntity<String> responseEP = restTemplate.exchange(endpoint, HttpMethod.GET, httpEntity, String.class);
            String responseBody = responseEP.getBody();
            System.out.println("responseBody" + responseBody);
            System.out.println(httpEntity);
            System.out.println(responseEP);
            return new ResponseEntity<>("TOKEN IS VALID", HttpStatus.OK);
        }catch(Exception e){
            String code = e.getMessage().substring(0, 3);
            if(code.equalsIgnoreCase("401")){
                return new ResponseEntity<>("INVALID TOKEN",HttpStatus.UNAUTHORIZED);
            }
        }

        return null;
    }
}
