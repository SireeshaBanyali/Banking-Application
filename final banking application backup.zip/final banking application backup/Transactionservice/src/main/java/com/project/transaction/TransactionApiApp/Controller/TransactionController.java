package com.project.transaction.TransactionApiApp.Controller;

import com.project.transaction.TransactionApiApp.Exceptions.UserDefinedException;
import com.project.transaction.TransactionApiApp.common.CommonMethods;
import com.project.transaction.TransactionApiApp.entity.*;
import com.project.transaction.TransactionApiApp.serviceImpl.TransactionServiceImple;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/transaction")
public class TransactionController {

    @Autowired
    private TransactionServiceImple transactionServiceImple;

    @Autowired
    private RestTemplate restTemplate;
    @Autowired
    private CommonMethods commanMethods;


    @PutMapping("/withdraw/deposit")
    public ResponseEntity<Object> DepositeAndwithdrawAmount(@RequestHeader("Authorization") String jwtToken,@RequestBody TransactionRequest request) {
        ResponseEntity<String> token=commanMethods.validateJwtToken(jwtToken);
        if(token.getStatusCodeValue()==401) {
            return new ResponseEntity<>("token is invalid ⌛⌛", HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity<Object> accountSummeryResponseEntity = null;

        if (request.getType().equalsIgnoreCase("Dp")) {
            return accountSummeryResponseEntity = transactionServiceImple.depositAmount(jwtToken,request);
        }
        if (request.getType().equalsIgnoreCase("Wd")) {
            return accountSummeryResponseEntity = transactionServiceImple.withdrawAmount(jwtToken,request);
        }
        throw new UserDefinedException("please provide valid transaction type 🙇‍♀️🙇‍♀️");
    }
    @PutMapping("fundTransaction")
    public ResponseEntity<Object> fundTransaction(@RequestHeader("Authorization") String jwtToken, @RequestBody FundTransferRequest request){
        ResponseEntity<String> token=commanMethods.validateJwtToken(jwtToken);
        if(token.getStatusCodeValue()==401) {
            return new ResponseEntity<>("token is invalid ⌛⌛⌛", HttpStatus.UNAUTHORIZED);
        }

        ResponseEntity accountSummaryEntity=transactionServiceImple.fundTrasaction(jwtToken,request);
        return accountSummaryEntity;


    }
    @GetMapping("fetch/Transactions")
    public ResponseEntity<Object> fetchTractions(@RequestHeader("Authorization") String jwtToken,@RequestBody FetchRequest request){

        ResponseEntity<String> token=commanMethods.validateJwtToken(jwtToken);
        if(token.getStatusCodeValue()==401) {
            return new ResponseEntity<>("token is invalid", HttpStatus.UNAUTHORIZED);
        }
        return new ResponseEntity<Object>(transactionServiceImple.fetchAllTransactions(request),HttpStatus.OK);

    }
}
