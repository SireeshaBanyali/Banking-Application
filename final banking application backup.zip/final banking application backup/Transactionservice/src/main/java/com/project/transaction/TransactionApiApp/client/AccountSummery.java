package com.project.transaction.TransactionApiApp.client;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class AccountSummery {


    private String accountNumber;
    private String  userName;
    private double currentBalance;
    private String token;

    public AccountSummery(String accountNumber, String userName, double currentBalance) {
        this.accountNumber = accountNumber;
        this.userName = userName;
        this.currentBalance = currentBalance;
    }
}
