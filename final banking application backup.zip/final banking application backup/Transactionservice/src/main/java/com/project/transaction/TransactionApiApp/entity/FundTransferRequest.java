package com.project.transaction.TransactionApiApp.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import lombok.AllArgsConstructor;
import lombok.Data;

//@Entity
@Data
@AllArgsConstructor
public class FundTransferRequest {

    private String userName;
    private String sourceAccountNumber;
    private String beneficiaryAccountNumber;
    private String type;
    private double ammount;


    /*private String token;*/

}
