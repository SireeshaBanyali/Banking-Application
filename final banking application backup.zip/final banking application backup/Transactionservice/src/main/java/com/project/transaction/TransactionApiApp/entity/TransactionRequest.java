package com.project.transaction.TransactionApiApp.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Transient;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Date;

@Entity
@Data
@NoArgsConstructor
public class TransactionRequest {
    @Id
    @GeneratedValue
    private int id;
    private String userName;
    private String accountNumber;
    private String type;
    @Transient
    private double amount;
    private double debitAmmount;
    private double creditAmmount;
    private String remarks;
    private Date date;

    public TransactionRequest(String type, double amount) {
        this.type = type;
        this.amount = amount;
    }

/*@Transient
    private String token;*/
}

