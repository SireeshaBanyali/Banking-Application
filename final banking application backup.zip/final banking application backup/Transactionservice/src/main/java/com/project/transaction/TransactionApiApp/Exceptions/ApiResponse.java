package com.project.transaction.TransactionApiApp.Exceptions;

public class ApiResponse {
    private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ApiResponse() {
        super();
        // TODO Auto-generated constructor stub
    }
}
