package com.project.transaction.TransactionApiApp.entity;

import lombok.Data;

import java.util.List;

@Data
public class FetchResponse {
    private String status;
    private List<DataForTransactions> data;
    private String error;
}
