package com.project.transaction.TransactionApiApp.entity;

import lombok.Data;

import java.sql.Date;

@Data
public class DataForTransactions {

    private Date date;
    private String remarks;
    private String Type;
    private double debitammount;
    private double creditammount;

}
