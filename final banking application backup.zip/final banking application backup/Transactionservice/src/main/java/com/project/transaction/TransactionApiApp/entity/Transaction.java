package com.project.transaction.TransactionApiApp.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.Data;

import java.sql.Date;

@Entity
@Data
public class Transaction {
    @Id
    @GeneratedValue
    private int transactionId;
    private Date transactionDate;
    private String TransactionType;
    private String Remarks;
}
