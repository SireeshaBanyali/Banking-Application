package com.project.transaction.TransactionApiApp.client;

import com.project.transaction.TransactionApiApp.Exceptions.UserDefinedException;
import com.project.transaction.TransactionApiApp.Repository.TransactionRequestRepository;
import com.project.transaction.TransactionApiApp.entity.FundTransferRequest;
import com.project.transaction.TransactionApiApp.entity.TransactionRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

@Component
public class AccountClient {

    @Autowired
    private RestTemplate restTemplate;

   /* @Autowired
   private TransactionRequestRepository transactionRequestRepository;*/


    public ResponseEntity<AccountSummery> depositAmmount(String jwtToken,TransactionRequest request) {
        String accountNumber = request.getAccountNumber();
        if(accountNumber==null){
            throw new UserDefinedException("please enter the Account number🖊️🖊️");
        }
        if(request.getUserName()==null){
            throw new UserDefinedException("please provide userName 🖊️🖊️");
        }
        if(request.getAmount() < 0){
            throw new UserDefinedException("Negative Amount "+request.getDebitAmmount()+" can not be added to the Account "+request.getAccountNumber()+". Kindly provide the correct amount to Perform the Deposit Transaction🙅‍♀️🙅‍♀️");
        }

        if(request.getAmount() >= 1000000){
            throw new UserDefinedException("Maxmimum deposit limit for Account Number "+request.getAccountNumber()+" is of Ten Lakhs💰💰");
        }
        ResponseEntity<AccountSummery> user = null;
        try {
            String endpoint = "http://localhost:8095/account/getUserByAccountNumber/{accountNumber}";
            user = restTemplate.getForEntity(endpoint, AccountSummery.class, accountNumber);
            System.out.println(user);
            if(user==null){
                throw new UserDefinedException("this source account does not exist in database 🔍🔍");
            }
            user.getBody().setCurrentBalance(user.getBody().getCurrentBalance()+request.getAmount());
            System.out.println(user);

            HttpHeaders headers = new HttpHeaders();
            headers.add("Authorization",jwtToken);
            AccountSummery summary=new AccountSummery(request.getAccountNumber(),request.getUserName(),user.getBody().getCurrentBalance());
            HttpEntity<AccountSummery> entity = new HttpEntity<>(summary, headers);

            ResponseEntity<Object> response = restTemplate.exchange(
                    "http://localhost:8095/account/updateAmountforUser/{accountNumber}",
                    HttpMethod.PUT,
                    entity,
                    Object.class,
                    accountNumber
            );

            return user;

        } catch (Exception e) {
            String code = e.getMessage().substring(0, 3);
            if (!code.equalsIgnoreCase("200")) {
                throw new UserDefinedException("no account found");
            }

        }
        return null;
    }
    public ResponseEntity<AccountSummery> withdrawAmmount(String jwtToken,TransactionRequest request) {
        String accountNumber = request.getAccountNumber();
        if(accountNumber==null){
            throw new UserDefinedException("please enter the Account number 🖊️🖊️");
        }
        if(request.getUserName()==null){
            throw new UserDefinedException("please provide userName👩👩");
        }
        if(request.getAmount() < 0){
            throw new UserDefinedException("Negative Amount "+request.getDebitAmmount()+" can not be added to the Account "+request.getAccountNumber()+". Kindly provide the correct amount to Perform the Deposit Transaction🙅‍♀️🙅‍♀️");
        }

        if(request.getAmount() >= 1000000){
            throw new UserDefinedException("Maxmimum deposit limit for Account Number "+request.getAccountNumber()+" is of Ten Lakhs");
        }
        ResponseEntity<AccountSummery> user = null;
        try {
            String endpoint = "http://localhost:8095/account/getUserByAccountNumber/{accountNumber}";
            user = restTemplate.getForEntity(endpoint, AccountSummery.class, accountNumber);
            System.out.println(user);
            if(user==null){
                throw new UserDefinedException("this source account does not exist in database 🔍🔍");
            }
            user.getBody().setCurrentBalance(user.getBody().getCurrentBalance()-request.getAmount());
            System.out.println(user);

            HttpHeaders headers = new HttpHeaders();
            headers.add("Authorization",jwtToken);
            AccountSummery summary=new AccountSummery(request.getAccountNumber(),request.getUserName(),user.getBody().getCurrentBalance());
            HttpEntity<AccountSummery> entity = new HttpEntity<>(summary, headers);

            ResponseEntity<Object> response = restTemplate.exchange(
                    "http://localhost:8095/account/updateAmountforUser/{accountNumber}",
                    HttpMethod.PUT,
                    entity,
                    Object.class,
                    accountNumber
            );

            return user;

        } catch (Exception e) {
            String code = e.getMessage().substring(0, 3);
            if (!code.equalsIgnoreCase("200")) {
                throw new UserDefinedException("no account found");
            }

        }
        return null;
    }

    public ResponseEntity<AccountSummery> fundTrasactionAmmount(String jwtToken,FundTransferRequest request){
        String sourceAccountNumber = request.getSourceAccountNumber();
        String benificinaryAccountNumber=request.getBeneficiaryAccountNumber();
        if(request.getSourceAccountNumber()==null){
            throw new UserDefinedException("please enter source Account Number 🖊️🖊️");
        }
        if(request.getBeneficiaryAccountNumber()==null){
            throw new UserDefinedException("please enter benificiary account number 🖊️🖊️");
        }
        if(request.getAmmount()<0){
            throw new UserDefinedException("negitive amount we can't transfer 🙅‍♀️🙅‍♀️");
        }
        try {
            ResponseEntity<AccountSummery> sourceAccountSummary = null;
            ResponseEntity<AccountSummery> beneficiaryAccountSummary = null;


            String endpoint = "http://localhost:8095/account/getUserByAccountNumber/{AccountNumber}";
            sourceAccountSummary = restTemplate.getForEntity(endpoint, AccountSummery.class, sourceAccountNumber);
          /* if(!request.getSourceAccountNumber().equals(sourceAccountSummary.getBody().getAccountNumber())){
               throw new UserDefinedException("source account not prest in the database");
           }*/
            if(sourceAccountSummary.getBody().getAccountNumber().equals(request.getSourceAccountNumber())) {
                sourceAccountSummary.getBody().setCurrentBalance(sourceAccountSummary.getBody().getCurrentBalance() - request.getAmmount());
                System.out.println(sourceAccountSummary.getBody().getCurrentBalance());

                HttpHeaders headers = new HttpHeaders();
                headers.add("Authorization",jwtToken);
                AccountSummery availableSourceHolderBal = new AccountSummery(request.getSourceAccountNumber(), request.getUserName(), sourceAccountSummary.getBody().getCurrentBalance());
                HttpEntity<AccountSummery> entity = new HttpEntity<>(availableSourceHolderBal, headers);
                ResponseEntity<Object> response = restTemplate.exchange(
                        "http://localhost:8095/account/updateAmountforUser/{accountNumber}",
                        HttpMethod.PUT,
                        entity,
                        Object.class,
                        sourceAccountNumber

                );

            }



            String endpoint2 = "http://localhost:8095/account/getUserByAccountNumber/{AccountNumber}";
            beneficiaryAccountSummary=restTemplate.getForEntity(endpoint2,AccountSummery.class,benificinaryAccountNumber);
            beneficiaryAccountSummary.getBody().setCurrentBalance(beneficiaryAccountSummary.getBody().getCurrentBalance()+request.getAmmount());
            String beneficiaryUserName=beneficiaryAccountSummary.getBody().getUserName();
            HttpHeaders headers = new HttpHeaders();
            headers.add("Authorization",jwtToken);
            AccountSummery availablebenificiaryHolderAmmount = new AccountSummery(request.getBeneficiaryAccountNumber(),beneficiaryUserName, beneficiaryAccountSummary.getBody().getCurrentBalance());

            HttpEntity<AccountSummery> entity = new HttpEntity<>(availablebenificiaryHolderAmmount, headers);
            ResponseEntity<Object> response = restTemplate.exchange(
                    "http://localhost:8095/account/updateAmountforUser/{accountNumber}",
                    HttpMethod.PUT,
                    entity,
                    Object.class,
                    benificinaryAccountNumber


            );

            return new ResponseEntity<>(availablebenificiaryHolderAmmount,HttpStatus.OK);






        } catch (Exception e) {
            String code = e.getMessage().substring(0, 3);
            if (!code.equalsIgnoreCase("200")) {
                throw new UserDefinedException("no account found ");
            }

        }
        return null;
    }
   }










