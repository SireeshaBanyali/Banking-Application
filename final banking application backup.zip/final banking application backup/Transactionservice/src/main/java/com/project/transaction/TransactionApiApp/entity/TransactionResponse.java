package com.project.transaction.TransactionApiApp.entity;

import lombok.Data;

@Data
public class TransactionResponse {
    private String status;

    private DataForTransactions data;
    private String error;

}
