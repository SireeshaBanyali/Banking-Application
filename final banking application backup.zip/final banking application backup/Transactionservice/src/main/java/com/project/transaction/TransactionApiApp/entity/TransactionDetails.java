package com.project.transaction.TransactionApiApp.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.Data;

@Entity
@Data
public class TransactionDetails {

    @Id
    @GeneratedValue
    private int transactionDetailsId;
    private int transactionId;
    private String accountNumber;

    private String postingType;

    private double amount;


}
