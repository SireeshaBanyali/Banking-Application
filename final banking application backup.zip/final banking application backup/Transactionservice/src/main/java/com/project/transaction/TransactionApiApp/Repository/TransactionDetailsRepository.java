package com.project.transaction.TransactionApiApp.Repository;

import com.project.transaction.TransactionApiApp.entity.TransactionDetails;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TransactionDetailsRepository extends JpaRepository<TransactionDetails,Integer> {
}
