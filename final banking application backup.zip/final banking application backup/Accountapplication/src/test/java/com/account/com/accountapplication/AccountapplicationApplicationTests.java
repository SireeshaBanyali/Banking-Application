package com.account.com.accountapplication;

import com.account.com.accountapplication.exception.UserDefinedException;
import com.account.com.accountapplication.model.UserAccount;
import com.account.com.accountapplication.repository.AccountRepository;
import com.account.com.accountapplication.serviceImpl.AccountServiceImpl;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.mockito.Mockito.when;

@SpringBootTest
class AccountapplicationApplicationTests {


	@Mock
	private AccountRepository accountRepository;

	@Autowired
	private AccountServiceImpl accountService;

	@Test
	void contextLoads() {
	}



	@Test
	//@Test(expected = UserDefinedException.class)
	public void createUserAccountShouldThrowExceptionWhenUsernameAlreadyExists() {
		try{
			UserAccount userAccount = new UserAccount();
			userAccount.setUserName("sasi@gmail.com");
			when(accountRepository.findByUserName("sasi@gmail.com")).thenReturn(new UserAccount());
			accountService.createUserAccount(userAccount);
		}catch(UserDefinedException e) {
		}
	}


	@Test
	//@Test(expected = UserDefinedException.class)
	public void createUserAccount() {
		//try{
		UserAccount userAccount = new UserAccount();
		userAccount.setAccountNumber("123456");
		when(accountRepository.findByAccountNumber("123456")).thenReturn(new UserAccount());
		assertEquals("123456",userAccount.getAccountNumber());
	}

	@Test
	public void createUserAccountShouldSetCurrentBalanceTo10000AndThrowException() {
		try{
			UserAccount userAccount = new UserAccount();
			userAccount.setUserName("Maneesha@gmail.com");
			when(accountRepository.findTopByOrderByIdDesc()).thenReturn(new UserAccount());
			when(accountRepository.save(userAccount)).thenReturn(userAccount);
			UserAccount savedUserAccount = accountService.createUserAccount(userAccount);
			assertEquals(10000, savedUserAccount.getCurrentBalance(), 0);
		}catch(UserDefinedException e) {
		}
	}
	@Test
	//@Test(expected = UserDefinedException.class)
	public void createUserAccountShouldThrowUserDefinedException() {
		try {
			UserAccount userAccount = new UserAccount();
			userAccount.setUserName("Bhanu@gmail.com");
			when(accountRepository.findTopByOrderByIdDesc()).thenReturn(new UserAccount());
			when(accountRepository.save(userAccount)).thenReturn(userAccount);
			UserAccount savedUserAccount = accountService.createUserAccount(userAccount);
			assertNotEquals("123456", savedUserAccount.getAccountNumber());
		} catch (UserDefinedException e) {

		}
	}

}


