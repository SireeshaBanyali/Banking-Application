package com.account.com.accountapplication.Controller;

import com.account.com.accountapplication.common.CommonMethods;
import com.account.com.accountapplication.model.UpdateRequest;
import com.account.com.accountapplication.model.UserAccount;
import com.account.com.accountapplication.service.AccountService;
import com.account.com.accountapplication.serviceImpl.AccountServiceImpl;
import org.junit.jupiter.api.Test;
import org.mockito.stubbing.OngoingStubbing;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class AccountControllerTest {


}








