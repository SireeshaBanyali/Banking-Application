package com.account.com.accountapplication.serviceImpl;

import com.account.com.accountapplication.exception.UserDefinedException;
import com.account.com.accountapplication.model.UserAccount;
import com.account.com.accountapplication.repository.AccountRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.dao.NonTransientDataAccessException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;

class AccountServiceImplTest {
    AccountRepository accountrepository=mock(AccountRepository.class);

    AccountServiceImpl service=mock(AccountServiceImpl.class);


    @BeforeEach
    public void setUp() {
        accountrepository = Mockito.mock(AccountRepository.class);
        AccountServiceImpl service=mock(AccountServiceImpl.class);
        service = new AccountServiceImpl();
    }


}