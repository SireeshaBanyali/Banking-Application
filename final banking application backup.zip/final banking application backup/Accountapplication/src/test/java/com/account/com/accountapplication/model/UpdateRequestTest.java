package com.account.com.accountapplication.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UpdateRequestTest {

    @Test
    public void testRequest(){
        UpdateRequest request=new UpdateRequest();
        request.setToken("eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJzaXJlZXNoYUBnbWFpbC5jb20iLCJleHAiOjE2ODE1NjcxNzEsImlhdCI6MTY4MTU2NjU3MX0.yZnrFEjvMc29Blo0ECBb1hsOZhzSNqS1QVZBoRWT45k");
        request.setCurrentBalance(100);
        assertEquals("eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJzaXJlZXNoYUBnbWFpbC5jb20iLCJleHAiOjE2ODE1NjcxNzEsImlhdCI6MTY4MTU2NjU3MX0.yZnrFEjvMc29Blo0ECBb1hsOZhzSNqS1QVZBoRWT45k",request.getToken());
        assertNotEquals("eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJzaXJlZXNoYUBnbWFpbC5jb20iLCJleHAiOjE2ODE1NjcxNzE",request.getToken());
    }
    @Test
    public void testRequestforAmount(){
        UpdateRequest request=new UpdateRequest();
        request.setToken("eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJzaXJlZXNoYUBnbWFpbC5jb20iLCJleHAiOjE2ODE1NjcxNzEsImlhdCI6MTY4MTU2NjU3MX0.yZnrFEjvMc29Blo0ECBb1hsOZhzSNqS1QVZBoRWT45k");
        request.setCurrentBalance(100);
        assertEquals(100,request.getCurrentBalance());
        assertNotEquals(1000,request.getCurrentBalance());
        assertNotNull(request);
    }
    @Test
    public void testRequestForNull() {
        UpdateRequest request = new UpdateRequest();
        assertNotNull(request);
    }

}