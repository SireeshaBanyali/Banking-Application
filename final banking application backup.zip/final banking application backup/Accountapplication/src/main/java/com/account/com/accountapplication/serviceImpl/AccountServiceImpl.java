package com.account.com.accountapplication.serviceImpl;

import com.account.com.accountapplication.exception.UserDefinedException;
import com.account.com.accountapplication.model.UpdateRequest;
import com.account.com.accountapplication.model.UserAccount;
import com.account.com.accountapplication.repository.AccountRepository;
import com.account.com.accountapplication.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Random;

@Service
public class AccountServiceImpl implements AccountService {

    @Autowired
    private AccountRepository accountRepository;

    public UserAccount createUserAccount(UserAccount userdetails){
        Random random = new Random();
        int generatedaccount = random.nextInt(10000) + 100000;
        /*UserAccount userByAccountNu=accountRepository.findByAccountNumber(userdetails.getAccountNumber());
        if(userByAccountNu!=null){
            throw new UserDefinedException("account  already exist");
        }
        UserAccount account = this.accountRepository.findTopByOrderByIdDesc();
        System.out.println(account);
        String nextAccountNumber = String.valueOf(Long.parseLong(account.getAccountNumber()) + 1);
        System.out.println(nextAccountNumber);
        userdetails.setAccountNumber(nextAccountNumber);*/


        UserAccount userAccountByUserName=accountRepository.findByUserName(userdetails.getUserName());
        if(userAccountByUserName!=null) {
            throw new UserDefinedException("userName already exist");

        }
        userdetails.setAccountNumber(String.valueOf(generatedaccount));

        userdetails.setCurrentBalance(10000);
        return accountRepository.save(userdetails);
    }



    public UserAccount getUserByAccounNumber(String accountNumber){
       // return accountRepository.getById(accountNumber);
       UserAccount account= accountRepository.findByAccountNumber(accountNumber);

        if(account==null){
            throw new UserDefinedException("no account");
        }

        return accountRepository.findByAccountNumber(accountNumber);
    }



    public UserAccount updateAmount(String AccountNumber, UpdateRequest request) {
        UserAccount account= accountRepository.findByAccountNumber(AccountNumber);
        if(account==null){
            throw new UserDefinedException("account not found");
        }
        account.setCurrentBalance(request.getCurrentBalance());

        return accountRepository.save(account);
    }

    public UserAccount getUserByUserName(String userName) {
        return accountRepository.findByUserName(userName);
    }
}

