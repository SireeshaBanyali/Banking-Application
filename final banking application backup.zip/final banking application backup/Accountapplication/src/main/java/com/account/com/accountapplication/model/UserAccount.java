package com.account.com.accountapplication.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;

@Entity
@Data

public class UserAccount {
    @Id
    private String accountNumber;
    private String userName;

    private double currentBalance;





}
