package com.account.com.accountapplication.Controller;

import com.account.com.accountapplication.common.CommonMethods;
import com.account.com.accountapplication.exception.UserDefinedException;
import com.account.com.accountapplication.model.UpdateRequest;
import com.account.com.accountapplication.model.UserAccount;
import com.account.com.accountapplication.serviceImpl.AccountServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/account")
public class AccountController {

    @Autowired
    private AccountServiceImpl accountServiceImpl;

    @Autowired
    private RestTemplate restTemplate;
    @Autowired
    private CommonMethods commonMethods;

    @PostMapping("/createUserAccount")
    public ResponseEntity<UserAccount> createUserAccount(@RequestBody UserAccount userDetails){

        return new ResponseEntity<UserAccount>(accountServiceImpl.createUserAccount(userDetails), HttpStatus.CREATED);
    }

    @GetMapping("/getUserByAccountNumber/{accountNumber}")
    public ResponseEntity<UserAccount> getUserByAccountNumber(@PathVariable("accountNumber") String accountNumber){
        return new ResponseEntity<UserAccount>(accountServiceImpl.getUserByAccounNumber(accountNumber),HttpStatus.OK);
    }



    @GetMapping("/getAccoutByUserName/{userName}")
    public UserAccount getAccountByUserName(@PathVariable(value = "userName") String userName){
        return accountServiceImpl.getUserByUserName(userName);
    }

    @PutMapping("/updateAmountforUser/{AccountNumber}")
    public ResponseEntity<Object> updateCurrentBalances(@PathVariable(value = "AccountNumber")String AccountNumber,@RequestHeader("Authorization") String jwtToken, @RequestBody UpdateRequest request) {
        ResponseEntity<String> token = commonMethods.validateJwtToken(jwtToken);
        System.out.println("Executing updateCurrentBalances() , AccountNumber : "+AccountNumber+" Update Req : "+request);
        if (token.getStatusCodeValue() == 401) {
            return new ResponseEntity<>("token is invalid", HttpStatus.UNAUTHORIZED);}
        return new ResponseEntity<Object>(accountServiceImpl.updateAmount(AccountNumber,request),HttpStatus.OK);
    }






    /*@GetMapping("/generate/accountNumber/next")
    public ResponseEntity<String> genNextAccountNumber(){
        UserAccount account = this.accountRepository.findTopByOrderByIdDesc();
        System.out.println(account);
        String nextAccountNumber = String.valueOf(Long.parseLong(account.getAccountNumber()) + 1);
        System.out.println(nextAccountNumber);

        return ResponseEntity.ok(nextAccountNumber);
    }
*/









    }




