package com.account.com.accountapplication.repository;

import com.account.com.accountapplication.model.UserAccount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface AccountRepository extends JpaRepository<UserAccount,String> {
    @Query(value = "select * from user_account where account_number=?",nativeQuery = true)
    public UserAccount findByAccountNumber(String accountNumber);

    @Query(value = "select * from user_account where user_name=?",nativeQuery = true)
    public UserAccount findByUserName(String userName);

    @Query(value ="select * from user_account order by account_number desc limit 1",nativeQuery = true)
    public UserAccount findTopByOrderByIdDesc();





}
