package com.account.com.accountapplication.model;

import lombok.*;

@Data

public class UpdateRequest {
    private  double currentBalance;

   /* private String token;*/


}
