package com.account.com.accountapplication.service;

import com.account.com.accountapplication.model.UpdateRequest;
import com.account.com.accountapplication.model.UserAccount;

public interface AccountService {

    public UserAccount createUserAccount(UserAccount userdetails);
    public UserAccount getUserByAccounNumber(String accountNumber);
    public UserAccount getUserByUserName(String userName);
    public UserAccount updateAmount(String AccountNumber, UpdateRequest request);
}

