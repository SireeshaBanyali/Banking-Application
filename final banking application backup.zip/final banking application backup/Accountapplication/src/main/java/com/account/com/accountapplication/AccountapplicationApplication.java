package com.account.com.accountapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class AccountapplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccountapplicationApplication.class, args);
		System.out.println("welcome");
	}

	@Bean
	public RestTemplate ClientRestTemplate(){

		return new RestTemplate();
	}


}
